//
//  File.swift
//  Back To The Moon
//
//  Created by Raffaele Siciliano on 14/04/22.
//

import Foundation
import SwiftUI

struct BackgroundView : View {
    var frameX = UIScreen.main.bounds
    var frameY = UIScreen.main.bounds
    var body : some View {
        ZStack {
            LinearGradient(colors: [Color.blueSky, Color.darkBlue], startPoint: .topLeading, endPoint: .bottomTrailing)
//          The Sun
            Circle()
                .frame(width: 400)
                .foregroundColor(Color.orange.opacity(0.3))
                .blur(radius: 30)
                .offset(x: -frameX.midX, y: -frameY.midY)
//            The Earth
            Circle()
                .frame(width: 300)
                .foregroundColor(Color.blue.opacity(0.3))
                .blur(radius: 30)
                .offset(x: frameX.minX, y: frameY.minY)
            Circle()
                .frame(width: 90)
                .foregroundColor(Color.green.opacity(0.3))
                .blur(radius: 30)
                .offset(x: frameX.minX-20, y: frameY.minY-20)
            Circle()
                .frame(width: 90)
                .foregroundColor(Color.green.opacity(0.3))
                .blur(radius: 30)
                .offset(x: frameX.minX+20, y: frameY.minY+20)
            Circle()
                .frame(width: 90)
                .foregroundColor(Color.green.opacity(0.3))
                .blur(radius: 30)
                .offset(x: frameX.minX-50, y: frameY.minY-50)
            Circle()
                .frame(width: 90)
                .foregroundColor(Color.green.opacity(0.3))
                .blur(radius: 30)
                .offset(x: frameX.minX-50, y: frameY.minY+20)
//            The Moon
            Circle()
                .frame(width: 135)
                .foregroundColor(Color.gray.opacity(0.3))
                .blur(radius: 30)
                .offset(x: frameX.midX/3, y: frameY.midY/2)

        }
    }
}
