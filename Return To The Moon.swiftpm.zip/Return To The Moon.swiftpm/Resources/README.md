## About Me

Display data from a central source in multiple views.

## Credits

# Images:

# - For the Apollo and Artemis covers: 
Apollo Cover Author: [CristianIS](https://pixabay.com/users/cristianis-2094012/)
Artemis Cover Author: [Andrew-Art](https://pixabay.com/users/andrew-art-2005827/)
[Pixabay License](https://pixabay.com/service/license/)

# - For the Apollo and Artemis missions:
These files are in the public domain in the United States because it was solely created by NASA. NASA copyright policy states that "NASA material is not protected by copyright unless noted". (See [NASA copyright policy](https://www.nasa.gov/multimedia/guidelines/index.html))

# Music: 
- For the music read the file named 
"ambient-freezing-night-28066-license.txt"
