//
//  File.swift
//  ToTheMoon
//
//  Created by Raffaele Siciliano on 11/04/22.
//

import Foundation
import SwiftUI
import AVFoundation

var audio : AVPlayer!

enum AppState {
    case mainScreen
    case discovering
}

typealias Instruction = (icon: String, title: String, description: String)

struct MainScreenProperties {
    static let appTitle: String = "RETURN TO THE MOON"
    
    static let appInstructions: [Instruction] = [
        (icon: "hand.tap", title: "Tap to Choose", description: "Tap to choose which program you want to explore."),
        (icon: "slider.horizontal.below.rectangle", title: "Use the Slider", description: "Use the Slider to go through the years and reach the Moon.")
    ]
    
    static let accentColor: Color = Color.indigo
}

struct Mission {
    var date : String
    var name : String
    var description : String
    var imageName : String
}

class AppData : ObservableObject {
    @Published var listApolloMission : [Mission] = [
        Mission(date: "1961-1972", name: "Apollo Program", description: "The Apollo program, also known as Project Apollo, was the third United States human spaceflight program carried out by the National Aeronautics and Space Administration (NASA), which succeeded in preparing and landing the first humans on the Moon from 1968 to 1972. It was first conceived during Dwight D. Eisenhower's administration as a three-person spacecraft to follow the one-person Project Mercury, which put the first Americans in space. Apollo was later dedicated to President John F. Kennedy's national goal for the 1960s of \"landing a man on the Moon and returning him safely to the Earth\" in an address to Congress on May 25, 1961. It was the third US human spaceflight program to fly, preceded by the two-person Project Gemini conceived in 1961 to extend spaceflight capability in support of Apollo.", imageName: "Apollo_Program"),
        Mission(date: "Oct 11–22, 1968", name: "Apollo 7", description: "Apollo 7 was the first crewed flight in NASA's Apollo program, and saw the resumption of human spaceflight by the agency after the fire that killed the three Apollo 1 astronauts during a launch rehearsal test on January 27, 1967. The Apollo 7 crew was commanded by Walter M. Schirra, with command module pilot Donn F. Eisele and lunar module pilot R. Walter Cunningham (so designated even though Apollo 7 did not carry a Lunar Module).", imageName: "Apollo_7_during_the_first_live_television_transmission_from_space"),
        Mission(date: "Jul 16–24, 1969", name: "Apollo 11", description: "Apollo 11 was the American spaceflight that first landed humans on the Moon. Commander Neil Armstrong and lunar module pilot Buzz Aldrin landed the Apollo Lunar Module Eagle on July 20, 1969, at 20:17 UTC, and Armstrong became the first person to step onto the Moon's surface six hours and 39 minutes later, on July 21 at 02:56 UTC. Aldrin joined him 19 minutes later, and they spent about two and a quarter hours together exploring the site they had named Tranquility Base upon landing. Armstrong and Aldrin collected 47.5 pounds (21.5 kg) of lunar material to bring back to Earth as pilot Michael Collins flew the Command Module Columbia in lunar orbit, and were on the Moon's surface for 21 hours, 36 minutes before lifting off to rejoin Columbia.", imageName: "Aldrin_Apollo_11_original"),
        Mission(date: "Nov 14–24, 1969", name: "Apollo 12", description: "Apollo 12 was the sixth crewed flight in the United States Apollo program and the second to land on the Moon. It was launched on November 14, 1969, from the Kennedy Space Center, Florida. Commander Charles \"Pete\" Conrad and Lunar Module Pilot Alan L. Bean performed just over one day and seven hours of lunar surface activity while Command Module Pilot Richard F. Gordon remained in lunar orbit.", imageName: "Surveyor_3-Apollo_12"),
        Mission(date: "Jan 31 – Feb 9, 1971", name: "Apollo 14", description: "Apollo 14 was the eighth crewed mission in the United States Apollo program, the third to land on the Moon, and the first to land in the lunar highlands. It was the last of the \"H missions\", landings at specific sites of scientific interest on the Moon for two-day stays with two lunar extravehicular activities (EVAs or moonwalks).", imageName: "Apollo_14_Shepard"),
        Mission(date: "Dec 7–19, 1972", name: "Apollo 17", description: "Apollo 17 was the final mission of NASA's Apollo program, the most recent time humans have set foot on the Moon or traveled beyond low Earth orbit. Commander Eugene Cernan and Lunar Module Pilot Harrison Schmitt walked on the Moon, while Command Module Pilot Ronald Evans orbited above. Schmitt was the only professional geologist to land on the Moon, selected in place of Joe Engle with NASA under pressure to send a scientist to the Moon. The mission's heavy emphasis on science meant the inclusion of a number of new experiments, including a biological experiment containing five mice carried in the command module.", imageName: "Eugene_Cernan_at_the_LM,_Apollo_17")
    ]
    @Published var listArtemisMission : [Mission] = [
        Mission(date: "2017-Present", name: "Artemis Program", description: "The Artemis program is a human spaceflight program that is being led by NASA with multiple international and US domestic partners. The primary goal of Artemis is to return humans to the Moon, specifically the lunar south pole, by 2025. If successful, it will include the first crewed lunar landing mission since Apollo 17 in 1972, which was the final lunar flight of the Apollo program. The Artemis program began in December 2017 as part of successive efforts to revitalize the U.S. space program. NASA's stated short-term goal for the program is landing the first woman and first person of color on the Moon; mid-term objectives include establishing an international expedition team, and a sustainable human presence on the Moon. Long-term objectives for Artemis are laying the foundations for the extraction of lunar resources, and eventually making crewed missions to Mars and beyond feasible.", imageName: "Artemis Program"),
        Mission(date: "June 2022", name: "Artemis I", description: "Artemis I is a planned uncrewed test flight for NASA's Artemis program. It is the first flight of the agency's Space Launch System (SLS) super heavy-lift launch vehicle and the first flight of the Orion MPCV. As of March 2022, Artemis 1 is expected to launch no earlier than May 2022. Formerly known as Exploration Mission-1 (EM-1), the mission was renamed after the introduction of the Artemis program. The launch will be held at Launch Complex 39B (LC-39B) at the Kennedy Space Center, where an Orion spacecraft will be sent on a mission of between 26 and 42 days, with at least 6 of those days in a distant retrograde orbit around the Moon. The mission will certify the Orion spacecraft and Space Launch System launch vehicle for crewed flights beginning with the second flight test of the Orion and Space Launch System, Artemis 2.", imageName: "Artemis1_mission-map_2019"),
        Mission(date: "May 2024", name: "Artemis II", description: "Artemis II is the second scheduled mission of NASA's Artemis program, and the first scheduled crewed mission of NASA's Orion spacecraft, currently planned to be launched by the Space Launch System (SLS) in May 2024. The crewed Orion spacecraft will perform a lunar flyby test and return to Earth. This is planned to be the first crewed spacecraft to travel beyond low Earth orbit since Apollo 17 in 1972. Formerly known as Exploration Mission-2 (EM-2), the mission was renamed after the introduction of the Artemis program. Originally, the crewed mission was intended to collect samples from a captured asteroid in lunar orbit by the now canceled robotic Asteroid Redirect Mission.", imageName: "Artemis_II_map_October_2021"),
        Mission(date: "2025", name: "Artemis III", description: "Artemis III will land a crew at the Moon's south polar region. It is planned to have two astronauts on the surface of the Moon for about one week. The mission is intended to be the first to place a woman on the Moon.[10] While up to four astronauts would leave Earth on board Orion, the surface mission with the Human Landing System (HLS) will consist of two crew members, who will remain on the surface for 6.5 days. The remaining astronauts will stay on board the Gateway / Orion orbital complex. The two astronauts will conduct up to four spacewalks on the Moon's surface, performing a variety of scientific observations, including sampling water ice. Before the Artemis 3 landing, some additional equipment will be pre-positioned on the surface, including an unpressurized rover for astronauts to use during their lunar excursions. This rover will have the capability to be controlled remotely. Several permanently shadowed regions could be reached by short forays of 5 to 15 km (3.1 to 9.3 mi), well within the range of the unpressurized rover.", imageName: "Artemis_III_Mission_profile_2025"),
        Mission(date: "March 2026", name: "Artemis IV", description: "The main objective of the mission will be assembly of the Gateway Space Station. The mission will deliver the I-Hab habitat module, developed by the European Space Agency and the Japanese space agency JAXA, to the Gateway. The module will be docked with the first Gateway elements, the Power and Propulsion Element and Habitation and Logistics Outpost. Artemis 4 will also be the first flight of the Block 1B version of the Space Launch System, which will replace the Interim Cryogenic Propulsion Stage used on the first three Artemis missions with the more powerful Exploration Upper Stage.", imageName: "Artemis_IV_Mission_profile_as_of_April_2022"),
        Mission(date: "2027", name: "Artemis V", description: "Artemis V will launch four astronauts to the Gateway Space Station. The mission will deliver the European Space Agency's ESPRIT refueling and communications module and a Canadian-built robotic arm system for the Gateway. Also delivered will be NASA's Lunar Terrain Vehicle. After docking to the Gateway, two astronauts will board to a docked Lunar Starship previously launched by SpaceX and fly it down to the Lunar south pole with the Lunar Terrain Vehicle on board. This will be the first lunar landing since Apollo 17 to utilize an unpressurized lunar rover.", imageName: "Artemis_V")
        ]
    
    
    func backgroundMusic() {
        let url = Bundle.main.url(forResource: "bgMusic", withExtension: "mp3")
        audio = AVPlayer.init(url: url!)
        audio.volume = 0.1
        audio.play()
    }
    
}

extension Color {
    static let darkBlue = Color("darkBlue")
    static let blueSky = Color("blueSky")
}
