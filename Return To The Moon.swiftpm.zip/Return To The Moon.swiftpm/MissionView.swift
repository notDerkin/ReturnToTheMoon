//
//  File.swift
//  ToTheMoon
//
//  Created by Raffaele Siciliano on 11/04/22.
//

import Foundation
import SwiftUI

struct MissionView: View {

    var mission : Mission
    
    var body: some View {
        ScrollView(showsIndicators: false) {
            Text(mission.date)
                .bold()
                .font(.system(size: 25))
            Image(mission.imageName)
                .resizable()
                .scaledToFit()
                .cornerRadius(25)
                .frame(height: 450)
                .padding(.leading, 15)
                .padding(.trailing, 15)
            Text(mission.description)
                .font(.system(size: 24))
                .padding(.top, 10)
                .padding(.leading, 25)
                .padding(.trailing, 25)
                .padding(.bottom, 20)
        }.navigationTitle(mission.name)
    }
}
