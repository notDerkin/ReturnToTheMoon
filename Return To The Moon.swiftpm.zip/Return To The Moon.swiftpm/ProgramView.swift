//
//  File.swift
//  ToTheMoon
//
//  Created by Raffaele Siciliano on 11/04/22.
//

import Foundation
import SwiftUI
import AVFoundation

struct ProgramView : View {
    
    let appData = AppData()
    let frameHeight = UIScreen.main.bounds.height
    let layout = [GridItem(.flexible())]
    
    var body : some View {
        
        
        NavigationView {
            ZStack {
                BackgroundView()
                    .ignoresSafeArea(.all)
                ScrollView(showsIndicators: false) {
                    ZStack {
                        HStack {
                            Text("🌎")
                            Spacer()
                            Text("🌕")
                        }
                        Text("🚀")
                        
                    }
                    .padding(.leading, 10)
                    .padding(.trailing, 10)
                    .font(.system(size: 50))
                    LazyVGrid(columns: layout, spacing: 5) {
                        NavigationLink(destination: MissionShower(missionList: appData.listApolloMission)) {
                            ZStack {
                                Image("Apollo_Program")
                                    .resizable()
                                    .scaledToFill()
                                Rectangle()
                                    .foregroundColor(.black).opacity(0.3)
                                VStack {
                                    Spacer()
                                    HStack {
                                        Text("From the Past:")
                                            .fontWeight(.bold)
                                            .font(.system(size: 30))
                                            .foregroundColor(.white)
                                            .font(.title)
                                            .padding(.leading, 30)
                                            .padding(.top, 20)
                                        Spacer()
                                    }
                                    HStack {
                                        Text("Apollo Program")
                                            .fontWeight(.bold)
                                            .font(.system(size: 75))
                                            .foregroundColor(.white)
                                            .font(.title)
                                            .padding(.leading, 25)
                                        Spacer()
                                    }
                                }
                                .padding(.bottom, 25)
                            }
                            .cornerRadius(25)
                        }
                        Spacer()
                        NavigationLink(destination: MissionShower(missionList: appData.listArtemisMission)) {
                            ZStack {
                                Image("Artemis Program")
                                    .resizable()
                                    .scaledToFill()
                                Rectangle()
                                    .foregroundColor(.black).opacity(0.3)
                                VStack {
                                    
                                    Spacer()
                                    HStack {
                                        Text("To the Future:")
                                            .fontWeight(.bold)
                                            .font(.system(size: 30))
                                            .foregroundColor(.white)
                                            .font(.title)
                                            .padding(.leading, 30)
                                            .padding(.top, 20)
                                        Spacer()
                                    }
                                    HStack {
                                        Text("Artemis Program")
                                            .fontWeight(.bold)
                                            .font(.system(size: 75))
                                            .foregroundColor(.white)
                                            .font(.title)
                                            .padding(.leading, 25)
                                        Spacer()
                                    }
                                }
                                .padding(.bottom, 25)
                            }
                            .cornerRadius(25)
                        }
                        
                    }
                    .padding(.horizontal)
                    .padding(.vertical)
                }
            }
        }
        .navigationViewStyle(StackNavigationViewStyle())
    }
}
