//
//  File.swift
//  Back To The Moon
//
//  Created by Raffaele Siciliano on 14/04/22.
//

import Foundation
import SwiftUI

struct ContentView: View {
    
    @State var currentAppState: AppState = .mainScreen

    var body: some View {
        
        switch currentAppState {
        case .mainScreen:
            MainScreenView(currentAppState: $currentAppState)
        case .discovering:
            ProgramView()
        }
    }
}
