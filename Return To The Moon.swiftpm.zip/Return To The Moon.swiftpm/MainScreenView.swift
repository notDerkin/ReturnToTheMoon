//
//  File.swift
//  ToTheMoon
//
//  Created by Raffaele Siciliano on 14/04/22.
//

import SwiftUI

struct MainScreenView: View {
    
    let appData = AppData()
    
    @Binding var currentAppState: AppState
    
    var appTitle: String = MainScreenProperties.appTitle
    
    var appInstructions: [Instruction] = MainScreenProperties.appInstructions
    
    let accentColor: Color = MainScreenProperties.accentColor
    
    var body: some View {
        ZStack {
            BackgroundView()
                .ignoresSafeArea(.all)
            VStack(alignment: .center, spacing: 16.0) {
                
                
                Text("\(self.appTitle)")
                    .font(.title)
                    .fontWeight(.black)
                    .shadow(color: self.accentColor, radius: 18, x: 0, y: 0)
                    .foregroundColor(.primary)
                    .padding(.top, 15)
                HStack {
                    Text("🌎")
                        .font(.system(size: 150))
                    Spacer()
                    VStack {
                        Text("👩🏽‍🚀")
                            .font(.system(size: 60))
                        Text("🧑🏼‍🚀")
                            .font(.system(size: 60))
                    }
                    Text("🚀")
                        .font(.system(size: 80))
                    Spacer()
                    Text("🌕")
                        .font(.system(size: 150))
                }
                .padding(.leading, 15)
                .padding(.trailing, 15)
                
                
                Spacer()
                
                ForEach(self.appInstructions, id: \.title) { instruction in
                    GroupBox(label: Label("\(instruction.title)", systemImage: "\(instruction.icon)").foregroundColor(self.accentColor)) {
                        HStack {
                            Text("\(instruction.description)")
                                .font(.callout)
                            Spacer()
                        }
                    }
                }
                
                Spacer()
                
                Button {
                    withAnimation { self.startApp() }
                } label: {
                    Text("START THE JOURNEY")
                        .fontWeight(.bold)
                        .padding()
                        .frame(maxWidth: .infinity)
                }
                .foregroundColor(.white)
                .background(self.accentColor)
                .cornerRadius(10.0)
                
            }
            .padding()
            .statusBar(hidden: true)
            .onAppear(){
                appData.backgroundMusic()
            }
        }
    }
    
    private func startApp() {
        self.currentAppState = .discovering
    }
}

struct MainScreen_Previews: PreviewProvider {
    static var previews: some View {
        MainScreenView(currentAppState: .constant(AppState.mainScreen))
        
    }
}
