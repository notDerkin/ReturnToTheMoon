import SwiftUI

@main
struct MyApp: App {
    
    var body: some Scene {
        WindowGroup {
            let appData = AppData()
            ContentView().preferredColorScheme(.dark).environmentObject(appData)
        }
    }
}
