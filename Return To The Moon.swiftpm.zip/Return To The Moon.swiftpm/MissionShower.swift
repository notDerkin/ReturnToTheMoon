import SwiftUI
import UIKit

struct MissionShower: View {
    
    @State private var missionCounter = 0
    var missionList : [Mission]
    @State private var opacityNext : Double = 1.0
    @State private var opacityPrevious : Double = 1.0
    @State var sliderValue : Double = 0.0
    
    
    
    var body: some View {
        ZStack {
            BackgroundView()
                .ignoresSafeArea(.all)
        VStack {
            VStack(spacing: 5) {
                ZStack{
                HStack {
                    Text("🌎")
                    Spacer()
                    Text("🌕")
                }
                .padding(.leading, 10)
                .padding(.trailing, 10)
                .font(.system(size: 50))
                    
            Slider(value: $sliderValue, in: 0...Double(missionList.count-1), step: 1.0)
                        .padding(.leading, 60)
                        .padding(.trailing, 60)
                    
                    
                }
                
            }

            MissionView(mission: missionList[Int(sliderValue)])
            Spacer()
            
        }
    }
    }
}
